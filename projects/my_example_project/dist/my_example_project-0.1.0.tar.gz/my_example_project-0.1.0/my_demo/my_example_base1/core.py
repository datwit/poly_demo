from my_demo.my_example_component.core import say_hello

say_hello()