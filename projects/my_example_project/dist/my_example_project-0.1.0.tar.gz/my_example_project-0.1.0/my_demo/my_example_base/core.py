from my_demo.my_example_component.core import say_hello
import requests

def main():
    print(say_hello())

if __name__ == '__main__':
    main()