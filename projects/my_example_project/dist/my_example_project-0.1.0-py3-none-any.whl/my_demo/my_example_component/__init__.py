from my_demo.my_example_component import core

__all__ = ["core"]

